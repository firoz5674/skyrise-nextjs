
import React from 'react'

const BlogTags = () => {
  return (
    <div>BlogTags</div>
  )
}

export default BlogTags