
import React from 'react'

const RecentBlogs = () => {
  return (
    <div>RecentBlogs</div>
  )
}

export default RecentBlogs