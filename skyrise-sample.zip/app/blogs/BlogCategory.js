

import React from 'react'

const BlogCategory = () => {
  return (
    <div>
      <h4 className='mb-3 leading-7'>Categories</h4>
      <div className="w-[60px] h-[5px] bg-button-gradient"></div>
    </div>
  )
}

export default BlogCategory