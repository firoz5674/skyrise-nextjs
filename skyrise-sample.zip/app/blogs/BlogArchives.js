
import React from 'react'

const BlogArchives = () => {
  return (
    <div>BlogArchives</div>
  )
}

export default BlogArchives