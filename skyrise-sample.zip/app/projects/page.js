
import React from 'react'

const Projects = () => {
  return (
    <section>
      <div className='container mx-auto px-4'>
        <h3>We are working on this page...</h3>
      </div>
    </section>
  )
}

export default Projects