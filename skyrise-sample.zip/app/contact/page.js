
import React from 'react'
import ContactMain from '../components/page-sections/contact'

const Contact = () => {
  return (
    <>
      <main>
        <ContactMain />
      </main>
    </>
  )
}

export default Contact